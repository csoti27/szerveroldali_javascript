/**
 * Visszaadja az adatbázisban tárolt összes növény adatát
 */