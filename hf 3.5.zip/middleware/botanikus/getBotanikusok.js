/**
 * Visszaadja az adatbázisban tárolt összes botanikus adatát
 */