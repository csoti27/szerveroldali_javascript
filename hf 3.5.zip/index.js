


const express = require('express');

//app.set('view engine', 'ejs');

const app = express();
const port = 3000;



/*
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/static/novenyek.html'));
});
*/

app.use(express.static('static'));
require('./route/index')(app);

app.listen(3000,()=>{
    console.log('Server started at http://localhost:' + port+"/novenyek.html");
});
