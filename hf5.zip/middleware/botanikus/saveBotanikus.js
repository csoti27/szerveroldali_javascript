/**
 * param: botanikusID (int)
 * Elmenti az adott ID-re a bevitt adatokat
 * Ha nincs botanikus ilyen ID-vel akkor létrehoz egyet a bevitt adatokkal
 * Ha van már ilyen ID-vel botanikus akkor átírja az adatait a bevitt adatokra
 */

 const requireOption = require('../requireOption');

 module.exports = function (objectrepository) {
     return function (req, res, next) {
         next();
     };
 };