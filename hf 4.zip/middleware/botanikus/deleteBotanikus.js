/**
 * param: botanikusID (int)
 * Törli az adott ID-hez tartozó botanikus
 * Ha nincs botanikus ilyen ID-vel akkor átirányít a főoldalra
 */