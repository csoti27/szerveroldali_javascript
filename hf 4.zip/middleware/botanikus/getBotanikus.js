/**
 * param: botanikusID (int)
 * Visszaadja az adott ID-hez tartozó botanikust
 * Ha nincs botanikus ilyen ID-vel akkor átirányít a főoldalra
 */