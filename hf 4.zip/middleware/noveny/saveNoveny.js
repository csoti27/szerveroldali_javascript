/**
 * param: novenyID (int)
 * Elmenti az adott ID-re a bevitt adatokat
 * Ha nincs növény ilyen ID-vel akkor létrehoz egyet a bevitt adatokkal
 * Ha van már ilyen ID-vel növény akkor átírja az adatait a bevitt adatokra
 */

 const requireOption = require('../requireOption');

 module.exports = function (objectrepository) {
     return function (req, res, next) {
         next();
     };
 };